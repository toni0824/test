---
name: revisao-texto
description: Aplica uma lista de verificação para rever textos em português quando o utilizador pede uma revisão.
---

# Revisão de texto

1. Lê o texto indicado pelo utilizador.
2. Verifica ortografia, concordância e clareza.
3. Apresenta cada problema com uma sugestão de correção.
4. Preserva o significado e não inventes factos.
