---
description: Conta as palavras do texto fornecido usando o script local.
allowed-tools: Bash(python3 scripts/contar_palavras.py:*)
argument-hint: texto
---

Executa `python3 scripts/contar_palavras.py` passando o texto abaixo como um
único argumento, devidamente protegido para a shell. Apresenta o resultado.
Se não existir texto, pede-o ao utilizador.

Texto: $ARGUMENTS
